/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

/**
 *
 * @author Djura Djurickovic
 */
public class Battleship {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Ship a = new Ship(4);
        Ship b = new Ship(2);
        Ship c = new Ship(3);
        
        
        a.fire();
        b.fire();
        c.fire();
        c.fire();
        b.fire();
        c.fire();
    }
}

/*
 * Purpose: Print Ascii table form 0 to 127
 * 
 *
 *   I, Djura Djurickovic 000140392 certify that this material is my original work.
 *     No other person's work has been used without due acknowledgement.
 *
 *
 */

package lab1a;

import java.util.Scanner;


public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        int numberOfColumn = 0;
        Scanner input = new Scanner(System.in);

        System.out.printf("How many groups: ");
        numberOfColumn = input.nextInt();


        for (int i = 0; i < 128; i++)
        {

            // if i is less then 10 and see if the following execptions prints
            // one way if else prints the other way
            if (i < 10)
            {
                if (i == 7 || i == 8 || i == 9)
                {
                    System.out.printf("   %x   %d    ", i, i);
                }
                else
                {
                    System.out.printf("%c  %x   %d    ", i, i, i);
                }


             }


             //if i is equal to 10 and 13 they are the excptions prints with out a char
             // else prints the rest of the numbers
            else
            {
                if (i == 10 || i == 13)
                {
                    System.out.printf("%4x%4d    ", i, i);
                }
                    // if i is greater then 16 prints rest of table
                else if (i < 16)
                 {
                       System.out.printf("%c%3x%4d    ", i, i, i);
                 }
                   
                     // If i is greater then 100 Print char Hex and Decimal
                   else if(i < 100 )
                {
                      System.out.printf("%c %x  %d    ", i, i, i);

                }

                else
                {

                    System.out.printf("%c %x %d    ", i, i, i);  // prints rest of the Ascii table

                }
             }


               // takes the itteration mods it by the number of columns then sees
               // if it is equal to zero to form the number of columns the user wants
            if (i % numberOfColumn == 0)
            {
                System.out.println();
            }


        }
    }
}









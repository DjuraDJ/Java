/**
 * Program : Lab 4 Card.java  
 * Purpose : This was a poker game originally but was switched to a Black jack game
 * Copyright I, Djura Djurickovic 000140392 certify that this material is my original work. No other
 * person's work has been used without due acknowledgement.
 */
/**
 * 
 * @author Djura Djurickovic 000140392
 */
public class Card {

    private String face; // face of card
    private String suit; // suit of card

    // two-argument constructor initializes card's face and suit
    /**
     * 
     * @param cardFace of Type String
     * @param cardSuit  of Type String
     */
    public Card(String cardFace, String cardSuit) {
        face = cardFace; // initialize face of card
        suit = cardSuit; // initialize suit of card
    } // end two-argument Card constructor
    
    /**
     * 
     * @return face 
     */
    public String getFace() {
        return face;
    } // end method getFace
/**
 * 
 * @return suit 
 */
    public String getSuit() {
        return suit;
    } 
/**
 * 
 * @return  concatenates face and suit 
 */
    public String toString() {
        return face + " of " + suit;
    } // end method toString
} // end class Card
/**
 * ************************************************************************
 * (C) Copyright 1992-2007 by Deitel & Associates, Inc. and * Pearson Education,
 * Inc. All Rights Reserved. * * DISCLAIMER: The authors and publisher of this
 * book have used their * best efforts in preparing the book. These efforts
 * include the * development, research, and testing of the theories and programs
 * * to determine their effectiveness. The authors and publisher make * no
 * warranty of any kind, expressed or implied, with regard to these * programs
 * or to the documentation contained in these books. The authors * and publisher
 * shall not be liable in any event for incidental or * consequential damages in
 * connection with, or arising out of, the * furnishing, performance, or use of
 * these programs. *
 ************************************************************************
 */


/**
 * Program : Lab 4 Main.java 
 * Purpose : This was a poker game originally but was switched to a Black jack game
 * Copyright I, Djura Djurickovic 000140392 certify that this material is my original work. No other
 * person's work has been used without due acknowledgement.
 */
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;
/**
 *
 * @author Djura Djurickovic 000140392
 */
public class Main {
    /**
     *
     * @param args
     */
    public static void main(String args[]) {
        int decksInShoe = 0;
        String hitOrStay;
        DeckOfCards shoe;
        ArrayList<Card> playerHand = new ArrayList<Card>();
        ArrayList<Card> dealerHand = new ArrayList<Card>();
        boolean bust = false;
        boolean correctInput = false;

        Scanner scan = new Scanner(System.in);
        final int NUMBER_OF_CARDS = 52; // constant number of cards
        // check to see what the input is if it is not numeric the try catch wiil 
        //be used  Try catch will be excuted till correct data is entered
        while (!correctInput) {

            System.out.print("How many decks of cards in the shoe? ");
            try {
                decksInShoe = scan.nextInt();
                correctInput = true;
            } catch (InputMismatchException e) {
                scan.next();  // clears the buffer 
            }
        }

        shoe = new DeckOfCards(decksInShoe); // creats a deck of cards object

        shoe.shuffle();  // shuffles the deck (shoe)
        // deals the card to players hand on card at a time from the shoe
        for (int i = 0; i < 2; i++) {
            playerHand.add(shoe.dealCard());

            System.out.printf("%s, ", playerHand.get(i)); // displays the cards
        }
        // ask user for more cards hit or stay
        System.out.println();
        System.out.println("You have: " + shoe.handValue(playerHand));
        System.out.print("hit or stay [h/s]: ");
        hitOrStay = scan.next(); 
         // if user Types "h" more cards are dealt
        while ("h".equals(hitOrStay) && bust == false) {
            playerHand.add(shoe.dealCard());
            // for each loop goes throw arraylist one card at a time and displays 
            for (Card currentCard : playerHand) {
                System.out.printf("%s, ", currentCard);
            }
            // assign the players hand value to a variable for readablity purpose
            int handValue = shoe.handValue(playerHand); 
            System.out.println();
            System.out.println("You have: " + handValue);
            // player has greater then 21 bust is set to true
            if (handValue > 21) {
                bust = true;
            } else {
                System.out.print("hit or stay [h/s]: ");
                hitOrStay = scan.next();
            }
        }
        /*
         *   bust is true dealer starts to play 
         *   i bascially copied the player hand  code to dealer hand.
         *   it is the same except for the dealer is not asked if the wish to hit or stay
         *   and the dealer must hit  greater then 16 and the dealer must stay on 17 or more 
         */
        if (!bust) {

            System.out.println();
            System.out.println("The dealer:");

            for (int i = 0; i < 2; i++) {
                dealerHand.add(shoe.dealCard());
                System.out.printf("%s, ", dealerHand.get(i));
            }
            int handValue = shoe.handValue(dealerHand);
            System.out.println();
            System.out.println("Dealer has: " + handValue);

            while (handValue <= 16) {
                dealerHand.add(shoe.dealCard());
                handValue = shoe.handValue(dealerHand);

                for (Card currentCard : dealerHand) {
                    System.out.print(currentCard + ", ");
                }

                System.out.println();
                System.out.println("Dealer has: " + handValue);
            }
        } else {
            System.out.println("dealer wins");
            System.exit(0);
        }
// decision on who wins dealer or your self 
        int playerTotal = shoe.handValue(playerHand);
        int dealerTotal = shoe.handValue(dealerHand);
        if (playerTotal > dealerTotal) {
            System.out.println("You WIN");
        } else if (playerTotal == dealerTotal) {
            System.out.println("dealer wins");
        } else if (dealerTotal > 21) {
            System.out.println("You WIN");
        } else {
            System.out.println("dealer wins");
        }

    } // end main
} // end class DeckOfCardsTest
/**
 * ************************************************************************
 * (C) Copyright 1992-2007 by Deitel & Associates, Inc. and * Pearson Education,
 * Inc. All Rights Reserved. * * DISCLAIMER: The authors and publisher of this
 * book have used their * best efforts in preparing the book. These efforts
 * include the * development, research, and testing of the theories and programs
 * * to determine their effectiveness. The authors and publisher make * no
 * warranty of any kind, expressed or implied, with regard to these * programs
 * or to the documentation contained in these books. The authors * and publisher
 * shall not be liable in any event for incidental or * consequential damages in
 * connection with, or arising out of, the * furnishing, performance, or use of
 * these programs. *
 ************************************************************************
 */

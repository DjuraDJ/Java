/**
 * 
 * Program: Cab.java
 * Purpose: The purpose of this program is to calculate the total amount of 
 * total fair my determining the weight distance time traveled  and with witch
 * cab used 1111 or 2222 
 * I, Djura Djurickovic  certify that this material is my original work. 
 * No other person's work has been used without due acknowledgement.
 */

package lab3;

public class Cab {

    private static double companyTotalFare = 0.0;
    private static double rate = 1.95;
    private double taxiTotalFare;
    private double tripFare;
    private int tripCounter;
    private int cabID;
    private Passenger rider;
/**
 * 
 * @param ID
 * constructor is called to assign ID to CabID 
 */
    public Cab(int ID) {
        cabID = ID;
    }
/**
 * 
 * @param weight
 * @param front 
 * 
 * creates a passenger and determines if passenger weight is less then 40
 */
    public void pickUp(double weight, boolean front) {
       double minWeightForAirBag = 40.0;
        
        rider = new Passenger(weight, front);
       
        if (rider.getWeight() < minWeightForAirBag && rider.getFront()) {
            System.out.println("PASSENGER AIRBAG IS OFF IN CAB " + cabID);
        }
    }
/**
 * 
 * @param minutes
 * to get trip fair rate * the number of minutes traveled
 * then that is add to the total of the taxi fair
 */
    public void dropOff(int minutes) {
        tripFare = rate * minutes;
        taxiTotalFare = taxiTotalFare + tripFare;
        tripCounter++;

        rider = null;
    }
/**
 * At the end of shift the total taxi fare is add to the company fare
 */
    public void EndOfShift() {
        companyTotalFare = companyTotalFare + taxiTotalFare;
    }
/**
 * displays to cab ID trip taken and the total fare and total company fare
 */
    public void displayStats() {

   System.out.printf("cab %d had %d trips and brought in $%.2f from the days $%.2f\n ",cabID 
                             ,tripCounter ,taxiTotalFare, companyTotalFare);
    }
}

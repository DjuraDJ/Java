/**
 * 
 * Program: Passenger.java
 * Purpose: The purpose of this program is to calculate the total amount of
 * total fair my determining the weight distance time traveled  and with witch 
 * cab used 1111 or 2222 
 * I, Djura Djurickovic  certify that this material is my original work. 
 * No other person's work has been used without due acknowledgement.
 */
package lab3;

public class Passenger {

    private double weight;
    private boolean front;
/**
 * 
 * @param weight
 * @param front 
 */
    public Passenger(double weight, boolean front) {
        this.weight = weight;
        this.front = front;
    }

/**
 * 
 * @return
 * returns the weight
 */
    public double getWeight() {
        return weight;
    }
/**
 * 
 * @return 
 * returns if passenger is sitting in front seat
 */
    public boolean getFront() {
        return front;
    }
}
